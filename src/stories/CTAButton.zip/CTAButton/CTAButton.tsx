// import React, { type SyntheticEvent } from "react";

// import type { SyntheticEvent } from "react";
import "./CTAButton.css";
import clsx from "clsx";
import { RotateLoader } from "react-spinners";

export interface CTAButtonProps {
  primary?: boolean;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "small" | "medium" | "large";
  disabled?: boolean;
  isLoading?: boolean;
  type?: "submit" | "button" | "reset";
  backgroundColor?: string;
  label: string;
  onClick?: () => void;
}

export const CTAButton = ({
  variant = "primary",
  size = "medium",
  disabled = false,
  isLoading,
  type = "button",
  backgroundColor,
  label = "testing",
  onClick,
}: CTAButtonProps) => {
  const className = clsx(
    `storybook-button`,
    `storybook-button--${size}`,
    `storybook-button--${variant}`,
    {
      "storybook-button--loading": isLoading,
    }
  );

  const handleClick = () => {
    onClick?.();
  };

  return (
    <button
      type={type}
      aria-busy={isLoading}
      onClick={handleClick}
      className={className}
      disabled={disabled}
      aria-disabled={disabled}
      style={{ backgroundColor }}
    >
      {isLoading ? <RotateLoader aria-busy aria-hidden /> : label}
    </button>
  );
};
